/**
 * @author Petr (http://www.sallyx.org/)
 */
package Chapter2StateMachines;

public enum location_type {
    shack,
    goldmine,
    bank,
    saloon,
    backyard;
    
    //set to true to send output to 'output.txt'
    final static public boolean TEXTOUTPUT = false;
};