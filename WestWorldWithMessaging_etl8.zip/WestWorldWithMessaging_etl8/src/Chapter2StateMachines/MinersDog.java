package Chapter2StateMachines;


import common.Messaging.Telegram;
import Chapter2StateMachines.MinersDogOwnedStates.NapAndSleep;
import static common.windows.*;
import static common.misc.ConsoleUtils.*;
/**
 *
 * @author emily leyendecker
 * @date 09.17.2018
 */
public class MinersDog extends BaseGameEntity {

    //an instance of the state machine class
    private StateMachine<MinersDog> m_pStateMachine;
    private location_type m_Location;
    
    //is dog already sleeping
    boolean m_dSleep;
    //after fatigue reaches max - dog takes nap
    private int m_dFatigue;
    //fatigue max
    final public static int MaxFatigue = 5;
    //how many bones a dog has stashed
    private int m_dBonesStashed;
    //amount of bones a dog must have before he is satisfied
    final public static int m_dSatisfied = 3;
    
    
    public MinersDog(EntityNames id) {
        super(id);
        m_Location = location_type.shack;
        m_dFatigue = 0;
        m_dBonesStashed = 0;
        
        m_pStateMachine = new StateMachine<MinersDog>(this);
        m_pStateMachine.SetCurrentState(NapAndSleep.Instance() );
    }

    @Override
    protected void finalize() throws Throwable { 
        super.finalize();
        this.m_pStateMachine = null;
    }
    
    public StateMachine<MinersDog> GetFSM() {
        return m_pStateMachine;
    }
    
    @Override
    public void Update() {
        SetTextColor(FOREGROUND_BLUE| FOREGROUND_INTENSITY);
        m_pStateMachine.Update();
    }
    
    @Override 
    public boolean HandleMessage(Telegram msg){
        return m_pStateMachine.HandleMessage(msg);
    }
 //---------------------------------------------------------------
    public boolean Fatigued() {
        if (m_dFatigue > MaxFatigue) {
            return true;
        }
        return false;
    }
    public void DecreaseFatigue() {
        m_dFatigue -= 1;
    }

    public void IncreaseFatigue() {
        m_dFatigue += 1;
    }
    
    public boolean SatisfiedDog() {
        return m_dBonesStashed == m_dSatisfied;
    }
    
    public void AddToBonePile(int val) {
        m_dBonesStashed += val;
        
        if (m_dBonesStashed < 0) {
            m_dBonesStashed = 0;
        }
    }
    
    public void SetBonesStashed(int val) {
        m_dBonesStashed = val;
    }

    public location_type Location() {
        return m_Location;
    }
    public void ChangeLocation(location_type loc) {
        m_Location = loc;
    }

}
