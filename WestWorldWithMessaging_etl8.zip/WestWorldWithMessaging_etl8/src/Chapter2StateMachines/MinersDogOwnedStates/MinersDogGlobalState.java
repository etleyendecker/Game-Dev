package Chapter2StateMachines.MinersDogOwnedStates;

/**
 *
 * @author emily leyendecker
 * @date 09.17.2018
 */

import common.Messaging.Telegram;
import Chapter2StateMachines.MinersDog;
import Chapter2StateMachines.MinersDogOwnedStates.BarkAtSquirrels;
import Chapter2StateMachines.State;
import static common.misc.utils.*;
import static common.misc.ConsoleUtils.*;
import static common.Time.CrudeTimer.*;
import static common.windows.*;
import static Chapter2StateMachines.MessageTypes.*;
import static Chapter2StateMachines.EntityNames.*;

public class MinersDogGlobalState extends State<MinersDog> {
    
    static final MinersDogGlobalState instance = new MinersDogGlobalState();
    
    private MinersDogGlobalState() {
    }
    
    @Override
    protected Object clone() throws CloneNotSupportedException {
        throw new CloneNotSupportedException("Cloning not allowed");
    }

    public static MinersDogGlobalState Instance() {
        return instance;
    }

    @Override
    public void Enter(MinersDog dog) {
    }

    @Override
    public void Execute(MinersDog dog) {
        //1 in 10 chance of squirrel running by dog
        if ((RandFloat() < 0.1) && !dog.GetFSM().isInState(BarkAtSquirrels.Instance())) {
            dog.GetFSM().ChangeState(BarkAtSquirrels.Instance());
        }
    }

    @Override
    public void Exit(MinersDog dog) {
    }

    @Override
    public boolean OnMessage(MinersDog dog, Telegram msg) {
        switch (msg.Msg) {
            case Msg_HiSpot: {
                cout("\nMessage handled by " + GetNameOfEntity(dog.ID()) + " at time: "
                        + Clock.GetCurrentTime());

                SetTextColor(FOREGROUND_BLUE | FOREGROUND_INTENSITY);

                cout("\n" + GetNameOfEntity(dog.ID())
                        + ": Bark Bark! ** runs and licks Miner's face");

                dog.GetFSM().ChangeState(NapAndSleep.Instance());
            }

            return true;
        }
        return false;
    }
}
