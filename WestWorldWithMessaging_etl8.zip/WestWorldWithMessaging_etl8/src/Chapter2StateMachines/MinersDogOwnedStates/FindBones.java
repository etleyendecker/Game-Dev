package Chapter2StateMachines.MinersDogOwnedStates;

/**
 *
 * @author emily leyendecker
 * @date 09.17.2018
 */

import common.Messaging.Telegram;
import Chapter2StateMachines.MinersDog;
import Chapter2StateMachines.State;
import Chapter2StateMachines.location_type;
import static Chapter2StateMachines.EntityNames.GetNameOfEntity;
import static common.misc.ConsoleUtils.*;
import static common.windows.*;
import static common.Time.CrudeTimer.*;

public class FindBones extends State<MinersDog> {
    
    static final FindBones instance = new FindBones();
    
    private FindBones(){
    }
    
    @Override
    protected Object clone() throws CloneNotSupportedException {
        throw new CloneNotSupportedException("Cloning not allowed");
    }

    public static FindBones Instance() {
        return instance;
    }
    
    @Override
    public void Enter(MinersDog pDog) {
        //if dog is not already in backyard, change location
        if (pDog.Location() != location_type.backyard){
            cout ("\n" + GetNameOfEntity(pDog.ID()) + ": " + "Bark **slips through doggy door**");
            pDog.ChangeLocation(location_type.backyard);
        }
    }
    
    @Override
    public void Execute(MinersDog pDog) {
        //if dog is outside, he digs for bones until he is fully satisfied
        //if dog reaches fatigue, goes to take a nap
  
        cout("\n" + GetNameOfEntity(pDog.ID()) + ": " + "Woof woof **digging into dirt**");
        
        pDog.AddToBonePile(1);
        pDog.IncreaseFatigue();
        
        if (pDog.SatisfiedDog()) {
            pDog.GetFSM().ChangeState(BarkAtSquirrels.Instance());
        }
        
        if (pDog.Fatigued()) {
            pDog.GetFSM().ChangeState(NapAndSleep.Instance());
        }
    }

    @Override
    public void Exit(MinersDog pDog) {
        cout("\n" + GetNameOfEntity(pDog.ID()) + ": " + "BARK ** trots back into shack**");    
    }

    @Override
    public boolean OnMessage(MinersDog pDog, Telegram msg) {
        SetTextColor(BACKGROUND_RED | FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE);
        
        switch (msg.Msg) {
            case Msg_HiSpot:
                
                cout("\nMessage handled by " + GetNameOfEntity(pDog.ID()) + " at time: " + Clock.GetCurrentTime());
                
                SetTextColor(FOREGROUND_BLUE | FOREGROUND_INTENSITY);
                
                cout("\n" + GetNameOfEntity(pDog.ID()) + ": Bark Bark! ** runs and licks Miner's face");
                
                pDog.GetFSM().ChangeState(NapAndSleep.Instance());
                
                return true;
        }
        return false;
    }
}
