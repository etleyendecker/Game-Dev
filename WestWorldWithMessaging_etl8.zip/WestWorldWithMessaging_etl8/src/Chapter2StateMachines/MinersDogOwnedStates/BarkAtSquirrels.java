package Chapter2StateMachines.MinersDogOwnedStates;

/**
 *
 * @author emily leyendecker
 * @date 09.17.2018
 */

import common.Messaging.Telegram;
import Chapter2StateMachines.MinersDog;
import Chapter2StateMachines.State;
import static Chapter2StateMachines.EntityNames.*;
import Chapter2StateMachines.location_type;
import static common.misc.ConsoleUtils.*;
import static common.windows.*;
import static common.Time.CrudeTimer.*;

public class BarkAtSquirrels extends State<MinersDog> {
    
    static final BarkAtSquirrels instance = new BarkAtSquirrels();
    
    private BarkAtSquirrels() {
    }
    
    @Override
    protected Object clone() throws CloneNotSupportedException {
        throw new CloneNotSupportedException("Cloning not allowed");
    }

    public static BarkAtSquirrels Instance() {
        return instance;
    }
    
    @Override
    public void Enter(MinersDog dog) {
        //if dog is not already in backyard, change location
        if (dog.Location() != location_type.backyard){
            cout ("\n" + GetNameOfEntity(dog.ID()) + ": " + "Bark **slips through doggy door**");
            dog.ChangeLocation(location_type.backyard);
        }
        cout("\n" + GetNameOfEntity(dog.ID()) + ": " + "**Ears perk up, Runs toward squirrel**");
    }

    @Override
    public void Execute(MinersDog dog) {
        cout("\n" + GetNameOfEntity(dog.ID()) + ": " + "BARK BARK BARK BARK");
        dog.IncreaseFatigue();
        if (dog.Fatigued() ) {
            dog.GetFSM().RevertToPreviousState();
        }
        
    }

    @Override
    public void Exit(MinersDog dog) {
       cout("\n" + GetNameOfEntity(dog.ID()) + ": " + "Growl.... **walks away**"); 
    }

    @Override
    public boolean OnMessage(MinersDog dog, Telegram msg) {
        SetTextColor(BACKGROUND_RED | FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE);
        
        switch (msg.Msg) {
            case Msg_HiSpot:
                
                cout("\nMessage handled by " + GetNameOfEntity(dog.ID()) + " at time: " + Clock.GetCurrentTime());
                
                SetTextColor(FOREGROUND_BLUE | FOREGROUND_INTENSITY);
                
                cout("\n" + GetNameOfEntity(dog.ID()) + ": Bark Bark! ** runs and licks Miner's face");
                
                dog.GetFSM().ChangeState(NapAndSleep.Instance());
                
                return true;
        }
        return false;
    }   
}
