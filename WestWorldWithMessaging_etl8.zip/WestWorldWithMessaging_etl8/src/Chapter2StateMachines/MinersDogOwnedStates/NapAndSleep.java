package Chapter2StateMachines.MinersDogOwnedStates;

/**
 *
 * @author emily leyendecker
 * @date 09.17.2018
 */
import common.Messaging.Telegram;
import Chapter2StateMachines.MinersDog;
import Chapter2StateMachines.State;
import Chapter2StateMachines.location_type;
import static Chapter2StateMachines.EntityNames.GetNameOfEntity;
import static common.misc.ConsoleUtils.*;
import static common.windows.*;
import static common.Time.CrudeTimer.*;

//------------------------------------------------------------------------
//  dog will sleep until fatigue is decreased to 0
//------------------------------------------------------------------------
public class NapAndSleep extends State<MinersDog> {
    
    static final NapAndSleep instance = new NapAndSleep ();
    
    private NapAndSleep() {
    }
    
    @Override
    protected Object clone() throws CloneNotSupportedException {
        throw new CloneNotSupportedException("Cloning not allowed");
    }

    static public NapAndSleep Instance() {
        return instance;
    }
    
    @Override
    public void Enter(MinersDog pDog) {
        if (pDog.Location() != location_type.shack) {
            cout("\n" + GetNameOfEntity(pDog.ID()) + ": " + "**Dog enters home through dog door**");
            pDog.ChangeLocation(location_type.shack);
        }
    }
    
    @Override
    public void Execute(MinersDog pDog) {
        //if dog not fatigued, start to find bones
        if (!pDog.Fatigued()) {
            cout("\n" + GetNameOfEntity(pDog.ID()) + ": " + "Yawn! **stretches and scratches ears**");
            pDog.GetFSM().ChangeState(FindBones.Instance() );
        } else {
            //sleeping
            pDog.DecreaseFatigue();
            cout("\n" + GetNameOfEntity(pDog.ID()) + ": " + "ZzzZzz..woof woof..");
        }
    }
    
    @Override
    public void Exit(MinersDog pDog) {
        cout("\n" + GetNameOfEntity(pDog.ID()) + ": " + "Bark Bark **trots to backyard**");
    }

    @Override
    public boolean OnMessage(MinersDog dog, Telegram msg) {
        SetTextColor(BACKGROUND_RED | FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE);
        
        switch (msg.Msg) {
            case Msg_HiSpot:
                
                cout("\nMessage handled by " + GetNameOfEntity(dog.ID()) + " at time: " + Clock.GetCurrentTime());
                
                SetTextColor(FOREGROUND_BLUE | FOREGROUND_INTENSITY);
                
                cout("\n" + GetNameOfEntity(dog.ID()) + ": Bark Bark! ** runs and licks Miner's face");
                
                dog.GetFSM().ChangeState(NapAndSleep.Instance());
                
                return true;
        }
        return false;
    }
}
